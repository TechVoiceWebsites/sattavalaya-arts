import { createFileRoute, Link } from "@tanstack/react-router";
import teacher from "@/assets/teacher.jpg";
import raji from "@/assets/Rajiwith.Veena.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Rajalakshmi Roshan | Sattvalaya Arts" },
      { name: "description", content: "Meet Rajalakshmi Roshan — Vainika, Bharatanatyam dancer, and yoga practitioner. Artistic Director of Sattvalaya Arts." },
      { property: "og:title", content: "Meet the Artistic Director — Sattvalaya Arts" },
      { property: "og:image", content: teacher },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <article className="px-5 sm:px-8 py-16">
      <div className="mx-auto max-w-5xl">
        <header className="text-center mb-14">
          <div className="text-xs uppercase tracking-[0.3em] text-vermilion/80 mb-3">Artistic Director</div>
          <h1 className="font-display text-5xl sm:text-6xl text-gradient-gold">Rajalakshmi Roshan</h1>
          <p className="mt-4 font-display italic text-xl text-ink/70">Vainika · Bharatanatyam Dancer · Yoga Practitioner</p>
        </header>

        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-12 items-start">
          <div className="lg:sticky lg:top-28">
            <div className="relative">
              <div className="absolute -inset-4 rounded-[2rem] blur-2xl opacity-50" style={{ background: "linear-gradient(135deg,#e9a04a,#c05a2a)" }} />
              <img src={teacher} alt="Rajalakshmi Roshan" className="relative rounded-3xl w-full aspect-[4/5] object-cover glass-card p-1.5" />
            </div>
          </div>

          <div className="space-y-5 text-ink/80 leading-relaxed text-[15px]">
            <p>Rajalakshmi Roshan is a biotechnologist by profession and a passionate Vainika, Bharatanatyam dancer, and yoga practitioner. Her journey with the Veena began at the age of 11 under the guidance of <strong>Veena Vidwan Guru Shri V. S. Rangarajan</strong>, whose teachings continue to inspire and shape her musical path.</p>
            <p>She completed her Veena Arangetram (solo debut performance) in 2005 in Chennai, India, and earned second place in the 2006 Musical Talent Hunt Contest hosted by Anna FM. Over the years, Rajalakshmi has performed in numerous Veena concerts across Chennai, sharing her deep love and devotion for this timeless instrument.</p>
            <p>Born and raised in Chennai — widely celebrated as the cultural capital of India — Rajalakshmi grew up immersed in the rich traditions of music and dance. Her strong cultural roots, combined with the blessings and discipline imparted by her guru, have played a defining role in her artistic journey.</p>
            <p>Through Sattvalaya Arts, Rajalakshmi aspires to share the beauty, depth, and versatility of the Veena with audiences from diverse cultural backgrounds. Her vision is to inspire and nurture the next generation of Vainikas by creating a joyful, supportive, and creative learning environment where tradition and passion come together.</p>

            <div className="grid grid-cols-3 gap-3 pt-4">
              {[{n:"2005",l:"Arangetram"},{n:"2006",l:"Anna FM Award"},{n:"2022",l:"Sattvalaya Founded"}].map((s) => (
                <div key={s.n} className="glass-card rounded-2xl p-4 text-center">
                  <div className="font-display text-2xl text-vermilion">{s.n}</div>
                  <div className="text-[11px] uppercase tracking-wider text-ink/60">{s.l}</div>
                </div>
              ))}
            </div>

            <div className="pt-6 flex flex-wrap gap-3">
              <Link to="/classes" className="rounded-full px-6 py-2.5 text-sm font-semibold text-cream" style={{ background: "linear-gradient(135deg,#9a3412,#c2410c)" }}>Explore Classes</Link>
              <Link to="/contact" className="rounded-full px-6 py-2.5 text-sm font-semibold border border-temple-gold/50">Get in Touch</Link>
            </div>
          </div>
        </div>

        <div className="mt-20 glass-card rounded-3xl p-10 text-center">
          <img src={raji} alt="" className="w-24 h-24 rounded-full object-cover mx-auto mb-4 ring-4 ring-temple-gold/30" />
          <p className="font-display italic text-2xl text-ink/80 max-w-2xl mx-auto">"To play the Veena is to listen — to the string, to the breath, to the silence between notes."</p>
          <div className="mt-3 text-xs uppercase tracking-[0.25em] text-vermilion">— Rajalakshmi Roshan</div>
        </div>
      </div>
    </article>
  );
}
