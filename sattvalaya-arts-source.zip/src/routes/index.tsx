import { createFileRoute, Link } from "@tanstack/react-router";
import heroImg from "@/assets/Rajiwith.Veena.jpg";
import logo from "@/assets/rajiroshanlogo.png";
import veenaClass from "@/assets/VeenaclassatNataRajiArts.jpg";
import yogaPose from "@/assets/TreePose.jpg";
import natarajasana from "@/assets/Natarajasana.jpg";
import meditation from "@/assets/meditation.jpg";
import gallery1 from "@/assets/pexels-sohanikamat-10491559.jpg";
import gallery2 from "@/assets/pexels-sohanikamat-10491567.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sattvalaya Arts — Harmony of Sound & Soul" },
      { name: "description", content: "Classical Veena and Yoga in San Jose, CA. Founded by Rajalakshmi Roshan. In-person, online, and hybrid classes for all ages." },
      { property: "og:title", content: "Sattvalaya Arts — Harmony of Sound & Soul" },
      { property: "og:description", content: "Veena & Yoga classes rooted in tradition, taught with care in San Jose, California." },
      { property: "og:image", content: heroImg },
      { name: "twitter:image", content: heroImg },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[88vh] flex items-center px-5 sm:px-8">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-12 items-center py-12">
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs uppercase tracking-[0.25em] bg-cream/70 border border-temple-gold/40 text-vermilion">
              <span className="w-1.5 h-1.5 rounded-full bg-vermilion" /> Est. 2022 · San Jose, CA
            </div>
            <h1 className="mt-6 font-display text-5xl sm:text-6xl lg:text-7xl leading-[1.05] text-ink">
              <span className="text-gradient-gold">Sattvalaya</span><br />Arts
            </h1>
            <p className="mt-4 font-display italic text-2xl sm:text-3xl text-vermilion/90">Harmony of Sound &amp; Soul</p>
            <p className="mt-6 max-w-xl text-base sm:text-lg text-ink/75 leading-relaxed">
              Classical Veena and Yoga rooted in tradition, taught with care.
              Discover the meditative depth of an ancient art — and a practice that quiets the mind.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/classes" className="rounded-full px-7 py-3 text-sm font-semibold text-cream shadow-lg hover:-translate-y-0.5 transition" style={{ background: "linear-gradient(135deg,#9a3412,#c2410c)" }}>
                Explore Classes
              </Link>
              <Link to="/about" className="rounded-full px-7 py-3 text-sm font-semibold border border-temple-gold/50 text-ink hover:bg-cream/60 transition">
                Meet the Teacher
              </Link>
            </div>
          </div>

          <div className="relative animate-fade-up" style={{ animationDelay: "0.2s" }}>
            <div className="absolute -inset-6 rounded-[2.5rem] opacity-60 blur-3xl" style={{ background: "radial-gradient(circle at 30% 30%, #e9a04a, transparent 60%), radial-gradient(circle at 70% 70%, #c05a2a, transparent 55%)" }} />
            <div className="relative overflow-hidden rounded-[2rem] glass-card p-2">
              <img src={heroImg} alt="Rajalakshmi Roshan playing Veena" className="w-full h-[520px] object-cover rounded-[1.75rem]" />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden sm:flex glass-card rounded-2xl px-5 py-3 items-center gap-3">
              <img src={logo} alt="" className="w-10 h-10 object-contain" />
              <div className="text-xs">
                <div className="font-semibold text-vermilion">Rajalakshmi Roshan</div>
                <div className="text-ink/60">Artistic Director</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT US */}
      <Section id="about" eyebrow="About Us" title="A Sanctuary for Tradition & Practice">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center">
          <div className="space-y-4 text-ink/80 leading-relaxed">
            <p>Founded in 2022 by <strong className="text-vermilion">Rajalakshmi Roshan</strong>, Sattvalaya Arts began as an initiative to nurture and educate aspiring students in the Veena. Rooted in tradition, the teaching approach guides students through both discipline and discovery.</p>
            <p>Classes focus on music theory, technique, and the nuanced art of playing the Veena, while fostering creativity and a deep love for the instrument. Each lesson is thoughtfully structured to balance technical precision with expressive growth.</p>
            <p>In addition to Veena training, Sattvalaya Arts offers yoga and meditation classes that support overall well-being, helping students cultivate balance in body, mind, and spirit.</p>
            <p>To ensure meaningful learning, class sizes are kept small so every student receives individual attention and personalized guidance throughout their journey.</p>
            <p>Classes are offered in <strong>San Jose, California</strong>, as well as through online and hybrid formats, welcoming students from around the world.</p>
            <Link to="/about" className="inline-flex mt-4 rounded-full px-6 py-2.5 text-sm font-semibold text-cream" style={{ background: "linear-gradient(135deg,#9a3412,#c2410c)" }}>Meet the Teacher</Link>
          </div>
          <div className="relative">
            <div className="glass-card rounded-3xl p-10 grid place-items-center aspect-square">
              <img src={logo} alt="Sattvalaya Arts logo" className="w-full max-w-xs object-contain animate-float" />
            </div>
          </div>
        </div>
      </Section>

      {/* THE SATTVALAYA APPROACH */}
      <Section eyebrow="Our Philosophy" title="The Sattvalaya Approach">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: "🎵", title: "A Foundation in Classical Veena", body: "Learn classical veena through a strong foundation in technique, rhythm, and bhava. Training is guided with respect to tradition while making learning accessible and joyful for all levels." },
            { icon: "🧘‍♀️", title: "Holistic Mind-Body Practice", body: "Through breath, movement, and mindful awareness, our yoga sessions build strength, flexibility, and inner stillness. The practice fosters balance and clarity, supporting overall well-being in daily life." },
            { icon: "🌍", title: "Flexible Learning for Modern Lifestyles", body: "In-person classes in the Bay Area, along with online and hybrid options, make it easy to stay consistent — whether you are a beginner, a returning learner, or learning alongside family." },
          ].map((c) => (
            <div key={c.title} className="glass-card rounded-3xl p-7 hover:-translate-y-1 transition">
              <div className="text-4xl mb-4">{c.icon}</div>
              <h3 className="font-display text-xl text-vermilion mb-3">{c.title}</h3>
              <p className="text-sm text-ink/75 leading-relaxed">{c.body}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* OUR CLASSES */}
      <Section eyebrow="Our Offerings" title="Our Classes">
        <div className="grid md:grid-cols-2 gap-8">
          <ClassCard img={veenaClass} title="Veena" subtitle="Carnatic classical tradition" body="From the first fret to advanced manodharma — a journey through Adi Tala Varnams, Kritis, gamakas, and the meditative beauty of the divine instrument." />
          <ClassCard img={yogaPose} title="Yoga" subtitle="Ashtanga · Vinyasa · Pranayama" body="60-minute sessions of breath, asana, and mindful awareness. Build strength, flexibility, and inner calm. All ages and levels welcome." />
        </div>
        <div className="mt-8 text-center">
          <Link to="/classes" className="inline-flex rounded-full px-7 py-3 text-sm font-semibold text-cream" style={{ background: "linear-gradient(135deg,#9a3412,#c2410c)" }}>View Class Details</Link>
        </div>
      </Section>

      {/* GALLERY */}
      <Section eyebrow="Moments" title="Gallery">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[gallery1, gallery2, veenaClass, yogaPose, natarajasana, meditation].map((g, i) => (
            <div key={i} className="group relative overflow-hidden rounded-2xl glass-card aspect-[4/3]">
              <img src={g} alt="" className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
            </div>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/gallery" className="inline-flex rounded-full px-7 py-3 text-sm font-semibold border border-temple-gold/50 hover:bg-cream/60 transition">See full gallery</Link>
        </div>
      </Section>
    </>
  );
}

function Section({ id, eyebrow, title, children }: { id?: string; eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="px-5 sm:px-8 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <div className="text-xs uppercase tracking-[0.3em] text-vermilion/80 mb-3">{eyebrow}</div>
          <h2 className="font-display text-4xl sm:text-5xl text-ink"><span className="text-gradient-gold">{title}</span></h2>
          <div className="mt-5 mx-auto w-24 ornament-divider"><span className="text-temple-gold">❋</span></div>
        </div>
        {children}
      </div>
    </section>
  );
}

function ClassCard({ img, title, subtitle, body }: { img: string; title: string; subtitle: string; body: string }) {
  return (
    <div className="glass-card rounded-3xl overflow-hidden group">
      <div className="relative h-64 overflow-hidden">
        <img src={img} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/60 to-transparent" />
        <div className="absolute bottom-4 left-5 text-cream">
          <div className="font-display text-3xl">{title}</div>
          <div className="text-xs uppercase tracking-[0.2em] opacity-90">{subtitle}</div>
        </div>
      </div>
      <div className="p-6 text-sm text-ink/75 leading-relaxed">{body}</div>
    </div>
  );
}
