import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import logoAsset from "@/assets/rajiroshanlogo.png";


const NAV = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/classes", label: "Classes" },
  { to: "/gallery", label: "Gallery" },
  { to: "/events", label: "Events" },
  { to: "/contact", label: "Contact" },
];

export default function SiteLayout() {
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => { setOpen(false); }, [path]);

  return (
    <div className="relative min-h-screen">
      

      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-xl bg-cream/80 border-b border-temple-gold/30">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <img src={logoAsset} alt="Sattvalaya Arts" className="w-12 h-12 object-contain rounded-lg shadow-sm" />
            <div className="leading-tight">
              <div className="font-display text-xl sm:text-2xl font-semibold text-gradient-gold">Sattvalaya Arts</div>
              <div className="text-[10px] sm:text-[11px] uppercase tracking-[0.25em] text-vermilion/80">Harmony of Sound &amp; Soul</div>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {NAV.map((n) => {
              const active = path === n.to;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`relative px-4 py-2 text-sm font-medium tracking-wide transition-colors ${active ? "text-vermilion" : "text-ink/75 hover:text-vermilion"}`}
                >
                  {n.label}
                  {active && <span className="absolute left-3 right-3 -bottom-0.5 h-px bg-gradient-to-r from-transparent via-vermilion to-transparent" />}
                </Link>
              );
            })}
            <Link
              to="/contact"
              className="ml-3 inline-flex items-center rounded-full px-5 py-2 text-sm font-semibold text-cream shadow-md transition hover:shadow-lg hover:-translate-y-0.5"
              style={{ background: "linear-gradient(135deg,#9a3412,#c2410c)" }}
            >
              Enroll Now
            </Link>
          </nav>

          <button
            aria-label="Menu"
            className="md:hidden w-10 h-10 grid place-items-center rounded-md text-ink"
            onClick={() => setOpen((o) => !o)}
          >
            <div className="space-y-1.5">
              <span className={`block h-0.5 w-6 bg-current transition ${open ? "translate-y-2 rotate-45" : ""}`} />
              <span className={`block h-0.5 w-6 bg-current transition ${open ? "opacity-0" : ""}`} />
              <span className={`block h-0.5 w-6 bg-current transition ${open ? "-translate-y-2 -rotate-45" : ""}`} />
            </div>
          </button>
        </div>

        {open && (
          <div className="md:hidden border-t border-temple-gold/20 bg-cream/95 backdrop-blur-xl">
            <div className="px-5 py-3 flex flex-col">
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} className="py-3 text-base font-medium text-ink border-b border-temple-gold/10 last:border-0">
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      <main className="pt-20">
        <Outlet />
      </main>

      <Footer />

      <a
        href="https://wa.me/14085551234"
        target="_blank"
        rel="noopener"
        aria-label="WhatsApp"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full grid place-items-center text-white shadow-xl hover:scale-110 transition"
        style={{ background: "linear-gradient(135deg,#25D366,#128C7E)" }}
      >
        <svg viewBox="0 0 24 24" className="w-7 h-7 fill-current"><path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.945C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 0 0 1.51 5.26l-.999 3.648 3.978-1.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.711.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg>
      </a>
    </div>
  );
}

function Footer() {
  return (
    <footer className="relative mt-24 border-t border-temple-gold/30 bg-cream/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <img src={logoAsset} alt="" className="w-12 h-12 object-contain" />
            <div>
              <div className="font-display text-2xl text-gradient-gold">Sattvalaya Arts</div>
              <div className="text-xs uppercase tracking-[0.25em] text-vermilion/80">Harmony of Sound &amp; Soul</div>
            </div>
          </div>
          <p className="text-sm text-ink/70 max-w-md leading-relaxed">
            Nurturing the timeless traditions of Veena and Yoga in the heart of San Jose, California.
            In-person, online, and hybrid classes for all ages.
          </p>
        </div>

        <div>
          <h4 className="font-display text-lg mb-3 text-vermilion">Explore</h4>
          <ul className="space-y-2 text-sm">
            {NAV.map((n) => (
              <li key={n.to}><Link to={n.to} className="text-ink/75 hover:text-vermilion transition">{n.label}</Link></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg mb-3 text-vermilion">Contact</h4>
          <ul className="space-y-2 text-sm text-ink/75">
            <li>San Jose, California</li>
            <li><a href="mailto:hello@sattvalayaarts.com" className="hover:text-vermilion">hello@sattvalayaarts.com</a></li>
            <li><a href="tel:+14085551234" className="hover:text-vermilion">+1 (408) 555-1234</a></li>
            <li className="pt-2 flex gap-3">
              {["facebook","instagram","youtube","linkedin"].map(s => (
                <a key={s} href="#" aria-label={s} className="w-9 h-9 grid place-items-center rounded-full border border-temple-gold/40 text-vermilion hover:bg-vermilion hover:text-cream transition">
                  <span className="text-xs font-bold">{s[0].toUpperCase()}</span>
                </a>
              ))}
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-temple-gold/20 py-5 text-center text-xs text-ink/60">
        © {new Date().getFullYear()} Sattvalaya Arts. All rights reserved.
      </div>
    </footer>
  );
}
